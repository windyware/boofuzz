Examples
========
Most of these examples are leftover from Sulley and may not be working.
The ftp- examples, however, are maintained and designed for boofuzz.