.. _install:
.. include:: ../../INSTALL.rst