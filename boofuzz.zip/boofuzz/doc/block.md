Block Class
===========
Blocks are added to Requests.
Blocks can contain Sulley Primitives, including other Blocks.